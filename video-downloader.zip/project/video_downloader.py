#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Video İndirici - yt-dlp kullanarak video indirme aracı
Bu betik, verilen URL'den en yüksek kalitede video indirir.
FFmpeg olmadan da çalışır, ancak FFmpeg ile daha iyi kalite elde edilir.

Kullanım öncesi gereksinimler:
- pip install yt-dlp
- FFmpeg kurulumu (isteğe bağlı, daha iyi kalite için)
"""

import os
import sys
import yt_dlp
import subprocess
import shutil
from pathlib import Path

def ilerleme_goster(d):
    """
    İndirme ilerlemesini gösteren callback fonksiyonu
    yt-dlp tarafından çağrılır ve indirme durumunu ekranda gösterir
    """
    if d['status'] == 'downloading':
        # İndirme devam ediyor
        try:
            yuzde = d.get('_percent_str', 'N/A')
            hiz = d.get('_speed_str', 'N/A')
            dosya_boyutu = d.get('_total_bytes_str', 'N/A')
            
            print(f"\r📥 İndiriliyor: {yuzde} | Hız: {hiz} | Boyut: {dosya_boyutu}", end='', flush=True)
        except:
            print("\r📥 İndiriliyor...", end='', flush=True)
    
    elif d['status'] == 'finished':
        # İndirme tamamlandı
        print(f"\n✅ İndirme tamamlandı: {d['filename']}")
    
    elif d['status'] == 'error':
        # İndirme hatası
        print(f"\n❌ İndirme hatası: {d.get('error', 'Bilinmeyen hata')}")

def ffmpeg_detayli_kontrol():
    """
    FFmpeg'in sisteme kurulu olup olmadığını detaylı şekilde kontrol eder
    Birden fazla yöntem kullanarak FFmpeg'i tespit etmeye çalışır
    """
    print("🔍 FFmpeg kontrolü yapılıyor...")
    
    # Yöntem 1: shutil.which ile PATH kontrolü
    ffmpeg_path = shutil.which('ffmpeg')
    if ffmpeg_path:
        print(f"✅ FFmpeg bulundu (PATH): {ffmpeg_path}")
        try:
            result = subprocess.run([ffmpeg_path, '-version'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                # FFmpeg versiyonunu al
                version_line = result.stdout.split('\n')[0]
                print(f"📋 {version_line}")
                return True, ffmpeg_path
        except Exception as e:
            print(f"⚠️  FFmpeg bulundu ama çalıştırılamadı: {e}")
    
    # Yöntem 2: Yaygın kurulum yollarını kontrol et
    yaygın_yollar = [
        '/usr/bin/ffmpeg',
        '/usr/local/bin/ffmpeg',
        '/opt/homebrew/bin/ffmpeg',  # macOS Homebrew (Apple Silicon)
        '/home/linuxbrew/.linuxbrew/bin/ffmpeg',  # Linux Homebrew
        'C:\\ffmpeg\\bin\\ffmpeg.exe',  # Windows yaygın kurulum
        'C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe',
        'C:\\Program Files (x86)\\ffmpeg\\bin\\ffmpeg.exe',
    ]
    
    for yol in yaygın_yollar:
        if os.path.exists(yol):
            print(f"✅ FFmpeg bulundu (sabit yol): {yol}")
            try:
                result = subprocess.run([yol, '-version'], 
                                      capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    version_line = result.stdout.split('\n')[0]
                    print(f"📋 {version_line}")
                    return True, yol
            except Exception as e:
                print(f"⚠️  FFmpeg bulundu ama çalıştırılamadı: {e}")
    
    # Yöntem 3: yt-dlp'nin kendi FFmpeg tespiti
    try:
        print("🔍 yt-dlp ile FFmpeg tespiti...")
        test_opts = {
            'format': 'bestvideo+bestaudio/best',
            'quiet': True,
            'no_warnings': True,
        }
        
        with yt_dlp.YoutubeDL(test_opts) as ydl:
            # yt-dlp'nin FFmpeg tespitini kontrol et
            if hasattr(ydl, '_get_exe_version'):
                try:
                    ffmpeg_version = ydl._get_exe_version('ffmpeg')
                    if ffmpeg_version:
                        print(f"✅ yt-dlp FFmpeg tespiti başarılı: {ffmpeg_version}")
                        return True, 'ffmpeg'
                except:
                    pass
    except Exception as e:
        print(f"⚠️  yt-dlp FFmpeg tespiti başarısız: {e}")
    
    print("❌ FFmpeg bulunamadı")
    return False, None

def video_indir(url):
    """
    Verilen URL'den videoyu indiren ana fonksiyon
    FFmpeg varsa en yüksek kalite, yoksa mevcut en iyi tek dosya formatını indirir
    
    Args:
        url (str): İndirilecek videonun URL'si
    
    Returns:
        bool: İndirme başarılı ise True, değilse False
    """
    
    # Detaylı FFmpeg kontrolü
    ffmpeg_var, ffmpeg_yolu = ffmpeg_detayli_kontrol()
    
    if ffmpeg_var:
        # FFmpeg var - en yüksek kalite ayarları
        ydl_opts = {
            'format': 'bestvideo[height<=2160]+bestaudio[acodec!=none]/bestvideo[height<=1440]+bestaudio[acodec!=none]/bestvideo[height<=1080]+bestaudio[acodec!=none]/best[height<=2160]/best',
            'outtmpl': '%(title)s.%(ext)s',
            'progress_hooks': [ilerleme_goster],
            'writesubtitles': False,
            'writeautomaticsub': False,
            'ignoreerrors': False,
            'merge_output_format': 'mp4',
            'postprocessors': [{
                'key': 'FFmpegVideoConvertor',
                'preferedformat': 'mp4',
            }],
        }
        
        # FFmpeg yolunu belirt (eğer standart PATH'te değilse)
        if ffmpeg_yolu and ffmpeg_yolu != 'ffmpeg':
            ydl_opts['ffmpeg_location'] = os.path.dirname(ffmpeg_yolu)
        
        print("🎯 FFmpeg bulundu - En yüksek kalite modunda indiriliyor")
        print("📋 Format: 4K/2K/1080p video + en iyi ses kalitesi")
    else:
        # FFmpeg yok - tek dosya formatı kullan ama daha iyi seçeneklerle
        ydl_opts = {
            'format': 'best[height<=2160][ext=mp4]/best[height<=1440][ext=mp4]/best[height<=1080][ext=mp4]/best[ext=mp4]/best',
            'outtmpl': '%(title)s.%(ext)s',
            'progress_hooks': [ilerleme_goster],
            'writesubtitles': False,
            'writeautomaticsub': False,
            'ignoreerrors': False,
        }
        print("⚠️  FFmpeg bulunamadı - Tek dosya formatında indiriliyor")
        print("💡 Daha iyi kalite için FFmpeg kurulumu önerilir")
        print("📋 Format: En iyi mevcut tek dosya (video+ses birleşik)")
    
    try:
        # yt-dlp nesnesini oluştur
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            print("\n🔍 Video bilgileri alınıyor...")
            
            # Video bilgilerini al (indirmeden önce kontrol için)
            info = ydl.extract_info(url, download=False)
            video_baslik = info.get('title', 'Bilinmeyen Video')
            video_suresi = info.get('duration', 0)
            
            # Video süresi formatla (saniye -> dakika:saniye)
            if video_suresi:
                dakika = video_suresi // 60
                saniye = video_suresi % 60
                sure_str = f"{dakika}:{saniye:02d}"
            else:
                sure_str = "Bilinmeyen"
            
            print(f"📺 Video: {video_baslik}")
            print(f"⏱️  Süre: {sure_str}")
            print(f"🌐 Platform: {info.get('extractor', 'Bilinmeyen')}")
            
            # Mevcut formatları göster
            if 'formats' in info and info['formats']:
                print("\n📋 Mevcut kalite seçenekleri:")
                formats = info['formats']
                
                # Video formatlarını filtrele ve göster
                video_formats = [f for f in formats if f.get('vcodec') != 'none' and f.get('height')]
                if video_formats:
                    # Yüksekten düşüğe sırala
                    video_formats.sort(key=lambda x: x.get('height', 0), reverse=True)
                    for i, fmt in enumerate(video_formats[:5]):  # İlk 5 formatı göster
                        height = fmt.get('height', 'N/A')
                        fps = fmt.get('fps', 'N/A')
                        vcodec = fmt.get('vcodec', 'N/A')
                        filesize = fmt.get('filesize')
                        size_str = f" (~{filesize//1024//1024}MB)" if filesize else ""
                        print(f"   • {height}p @ {fps}fps ({vcodec}){size_str}")
                        if i >= 4:  # Maksimum 5 format göster
                            break
            
            # Kullanıcıdan onay al
            onay = input("\n🤔 Bu videoyu indirmek istiyor musunuz? (e/h): ").lower().strip()
            
            if onay in ['e', 'evet', 'yes', 'y']:
                print("\n🚀 İndirme başlatılıyor...\n")
                
                # Gerçek indirme işlemi
                ydl.download([url])
                
                print("\n🎉 Video başarıyla indirildi!")
                print("📁 Dosya mevcut dizinde kaydedildi.")
                
                # İndirilen dosyayı bul ve boyutunu göster
                try:
                    for file in os.listdir('.'):
                        if file.startswith(video_baslik[:20]) and file.endswith(('.mp4', '.mkv', '.webm')):
                            file_size = os.path.getsize(file) / (1024 * 1024)  # MB
                            print(f"📊 Dosya boyutu: {file_size:.1f} MB")
                            break
                except:
                    pass
                
                return True
            else:
                print("❌ İndirme iptal edildi.")
                return False
                
    except yt_dlp.utils.DownloadError as e:
        error_msg = str(e)
        print(f"\n❌ İndirme hatası: {error_msg}")
        
        # FFmpeg hatası özel kontrolü
        if "ffmpeg" in error_msg.lower():
            print("🔧 FFmpeg ile ilgili bir sorun tespit edildi!")
            print("💡 Çözüm önerileri:")
            print("   1. FFmpeg'in PATH'te olduğundan emin olun")
            print("   2. FFmpeg'i yeniden kurun")
            print("   3. Sistem yeniden başlatın")
            print("   4. Veya tek dosya modunda tekrar deneyin")
        else:
            print("💡 Muhtemel sebepler:")
            print("   - Geçersiz URL")
            print("   - Özel/kısıtlı video")
            print("   - Coğrafi kısıtlama")
            print("   - Video artık mevcut değil")
        return False
        
    except Exception as e:
        print(f"\n❌ Beklenmeyen hata: {str(e)}")
        print("💡 Lütfen URL'yi kontrol edin ve tekrar deneyin.")
        return False

def ffmpeg_kurulum_rehberi():
    """
    FFmpeg kurulum rehberini gösterir
    """
    print("\n" + "="*60)
    print("🔧 FFMPEG KURULUM REHBERİ")
    print("="*60)
    print("FFmpeg, video ve ses dosyalarını işlemek için güçlü bir araçtır.")
    print("En yüksek kalitede video indirmek için gereklidir.\n")
    
    print("📥 KURULUM:")
    print("• Windows:")
    print("  1. https://ffmpeg.org/download.html adresine gidin")
    print("  2. 'Windows builds by BtbN' linkine tıklayın")
    print("  3. 'ffmpeg-master-latest-win64-gpl.zip' dosyasını indirin")
    print("  4. Zip dosyasını C:\\ffmpeg klasörüne çıkarın")
    print("  5. C:\\ffmpeg\\bin klasörünü sistem PATH'ine ekleyin")
    print("  6. Veya Chocolatey ile: choco install ffmpeg")
    print("  7. Veya Scoop ile: scoop install ffmpeg")
    print()
    print("• macOS:")
    print("  brew install ffmpeg")
    print("  (Homebrew kurulu değilse: /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\")")
    print()
    print("• Ubuntu/Debian:")
    print("  sudo apt update && sudo apt install ffmpeg")
    print()
    print("• CentOS/RHEL/Fedora:")
    print("  sudo dnf install ffmpeg")
    print("  (Eski sürümler için: sudo yum install ffmpeg)")
    print()
    print("• Arch Linux:")
    print("  sudo pacman -S ffmpeg")
    print()
    print("✅ Kurulum sonrası terminalde 'ffmpeg -version' komutu çalışmalıdır.")
    print("🔄 Kurulum sonrası sistemi yeniden başlatmanız gerekebilir.")
    print("="*60)

def sistem_bilgisi():
    """
    Sistem bilgilerini gösterir (debug için)
    """
    print("\n" + "="*60)
    print("🖥️  SİSTEM BİLGİLERİ")
    print("="*60)
    print(f"🐍 Python: {sys.version}")
    print(f"💻 Platform: {sys.platform}")
    print(f"📁 Çalışma dizini: {os.getcwd()}")
    
    # PATH bilgisi
    path_dirs = os.environ.get('PATH', '').split(os.pathsep)
    print(f"🛤️  PATH dizin sayısı: {len(path_dirs)}")
    
    # yt-dlp versiyonu
    try:
        print(f"📺 yt-dlp: {yt_dlp.version.__version__}")
    except:
        print("📺 yt-dlp: Versiyon bilgisi alınamadı")
    
    print("="*60)

def main():
    """
    Ana program fonksiyonu - kullanıcı arayüzü
    """
    
    # Program başlığı
    print("=" * 60)
    print("🎬 VİDEO İNDİRİCİ - yt-dlp ile Akıllı Kalite v2.0")
    print("=" * 60)
    
    # Sistem bilgisi seçeneği
    debug = input("🔧 Sistem bilgilerini görmek ister misiniz? (e/h): ").lower().strip()
    if debug in ['e', 'evet', 'yes', 'y']:
        sistem_bilgisi()
    
    # İlk FFmpeg kontrolü
    print("\n🔍 Sistem kontrolü yapılıyor...")
    ffmpeg_var, ffmpeg_yolu = ffmpeg_detayli_kontrol()
    
    if ffmpeg_var:
        print("✅ FFmpeg bulundu - En yüksek kalite modu aktif!")
        print(f"📍 Konum: {ffmpeg_yolu}")
    else:
        print("⚠️  FFmpeg bulunamadı - Tek dosya modu aktif")
        print("💡 Daha iyi kalite için FFmpeg kurulumu önerilir")
        
        # FFmpeg kurulum rehberi seçeneği
        rehber = input("🤔 FFmpeg kurulum rehberini görmek ister misiniz? (e/h): ").lower().strip()
        if rehber in ['e', 'evet', 'yes', 'y']:
            ffmpeg_kurulum_rehberi()
            input("\n⏎ Devam etmek için Enter'a basın...")
    
    print()
    
    # Desteklenen platformları göster
    print("🌐 Desteklenen platformlar:")
    print("   • YouTube, YouTube Music")
    print("   • Instagram, Facebook")
    print("   • Twitter, TikTok")
    print("   • Dailymotion, Vimeo")
    print("   • Ve 1000+ platform daha!")
    print()
    
    while True:
        try:
            # Kullanıcıdan URL al
            print("📝 Lütfen indirmek istediğiniz videonun URL'sini girin:")
            print("   (Çıkmak için 'q' veya 'quit' yazın)")
            
            url = input("🔗 URL: ").strip()
            
            # Çıkış kontrolü
            if url.lower() in ['q', 'quit', 'çık', 'exit']:
                print("👋 Hoşçakalın!")
                break
            
            # Boş URL kontrolü
            if not url:
                print("❌ Lütfen geçerli bir URL girin!\n")
                continue
            
            # URL format kontrolü (basit)
            if not (url.startswith('http://') or url.startswith('https://')):
                print("❌ URL 'http://' veya 'https://' ile başlamalıdır!\n")
                continue
            
            print("-" * 60)
            
            # İndirme işlemini başlat
            basari = video_indir(url)
            
            print("-" * 60)
            
            if basari:
                # Başka video indirmek isteyip istemediğini sor
                devam = input("\n🔄 Başka bir video indirmek istiyor musunuz? (e/h): ").lower().strip()
                if devam not in ['e', 'evet', 'yes', 'y']:
                    print("👋 Hoşçakalın!")
                    break
            else:
                print("🔄 Lütfen tekrar deneyin veya farklı bir URL girin.")
            
            print()  # Boş satır
            
        except KeyboardInterrupt:
            print("\n\n⏹️  Program kullanıcı tarafından durduruldu.")
            print("👋 Hoşçakalın!")
            break
        except Exception as e:
            print(f"\n❌ Beklenmeyen hata: {str(e)}")
            print("🔄 Lütfen tekrar deneyin.\n")

if __name__ == "__main__":
    """
    Program ana giriş noktası
    """
    try:
        main()
    except Exception as e:
        print(f"❌ Kritik hata: {str(e)}")
        print("🔧 Lütfen kütüphanelerin doğru kurulduğundan emin olun.")
        sys.exit(1)

"""
📋 KURULUM TALİMATLARI:

1. yt-dlp kütüphanesini kurun:
   pip install yt-dlp

2. FFmpeg'i kurun (önerilen):
   - Windows: https://ffmpeg.org/download.html veya choco install ffmpeg
   - macOS: brew install ffmpeg
   - Ubuntu/Debian: sudo apt install ffmpeg
   - CentOS/RHEL: sudo dnf install ffmpeg

3. Betiği çalıştırın:
   python video_downloader.py

📌 YENİ ÖZELLİKLER v2.0:

• GELİŞMİŞ FFMPEG TESPİTİ:
  - Çoklu tespit yöntemi (PATH, sabit yollar, yt-dlp tespiti)
  - Detaylı FFmpeg versiyon bilgisi
  - Kurulum yolu gösterimi

• DAHA İYİ KALİTE SEÇİMİ:
  - 4K/2K/1080p öncelikli format seçimi
  - Akıllı codec seçimi
  - Dosya boyutu optimizasyonu

• GELİŞMİŞ KULLANICI ARAYÜZÜ:
  - Mevcut kalite seçeneklerini gösterir
  - İndirilen dosya boyutunu gösterir
  - Sistem bilgisi debug modu

• DAHA İYİ HATA YÖNETİMİ:
  - FFmpeg özel hata tespiti
  - Detaylı çözüm önerileri
  - Sistem uyumluluk kontrolü

📌 ÖNEMLİ NOTLAR:

• FFMPEG KURULUMU:
  - Windows: PATH'e eklemeyi unutmayın
  - macOS: Homebrew kullanın (brew install ffmpeg)
  - Linux: Paket yöneticisi kullanın (apt/dnf/pacman)

• KALİTE FARKI:
  - FFmpeg ile: 4K video + yüksek kalite ses = Mükemmel kalite
  - FFmpeg olmadan: Hazır birleşik dosya = İyi kalite

• SORUN GİDERME:
  - FFmpeg kurulu ama algılanmıyor: Sistem yeniden başlatın
  - PATH sorunu: FFmpeg'i manuel olarak PATH'e ekleyin
  - İzin sorunu: Yönetici olarak çalıştırın

• YASAL UYARI:
  - Sadece izin verilen ve telif hakkı olmayan videoları indirin
  - Bu araç eğitim amaçlıdır, kötüye kullanım sorumluluğu kullanıcıya aittir
"""